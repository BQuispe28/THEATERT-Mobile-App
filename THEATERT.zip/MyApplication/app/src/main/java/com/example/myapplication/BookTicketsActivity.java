package com.example.myapplication;


import android.os.Bundle;
import android.view.View;
import android.widget.Button;
import android.widget.EditText;
import android.widget.Toast;

import androidx.appcompat.app.AppCompatActivity;

public class BookTicketsActivity extends AppCompatActivity {

    private EditText editTextEventID;
    private EditText editTextTitle;
    private EditText editTextGenre;
    private EditText editTextTicketCount;
    private Button buttonBookTickets;
    private Database database;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_book_shows);

        database = new Database(this);

        editTextEventID = findViewById(R.id.eventIDEditText);
        editTextTitle = findViewById(R.id.titleEditText);
        editTextGenre = findViewById(R.id.genreEditText);
        editTextTicketCount = findViewById(R.id.ticketCountEditText);
        buttonBookTickets = findViewById(R.id.addButton);

        buttonBookTickets.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                String eventID = editTextEventID.getText().toString();
                String title = editTextTitle.getText().toString();
                String genre = editTextGenre.getText().toString();
                int ticketCount = Integer.parseInt(editTextTicketCount.getText().toString());

                addBooking(eventID, title, genre, ticketCount);
            }
        });
    }

    private void addBooking(String eventID, String title, String genre, int ticketCount) {
        database.addBooking(eventID, title, genre, ticketCount);
        Toast.makeText(this, "Booking added successfully", Toast.LENGTH_SHORT).show();
        clearFields();
    }

    private void clearFields() {
        editTextEventID.setText("");
        editTextTitle.setText("");
        editTextGenre.setText("");
        editTextTicketCount.setText("");
    }
}
